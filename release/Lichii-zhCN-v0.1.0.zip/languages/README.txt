把 zh_CN.qm 保留在此目录（lichii.exe 同级的 languages 文件夹）。
在 Lichii「设置 -> 界面 -> 语言」中选择 Chinese (China) 即可启用。
更新语言包：替换本文件并重启 Lichii。
